// pages/UserTimerPage/index.tsx
import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { get, ref } from 'firebase/database';
import { database } from '~/constants/firebase';
import { AccumulatedTimerPage } from './components/AccumulatedTimerPage';
import { RecordTimerPage } from './components/RecordTimerPage';

export function UserTimerPage() {
  const { uid, timerId } = useParams<{ uid: string; timerId: string }>();
  const [hasAccumulatedMs, setHasAccumulatedMs] = useState<boolean | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!uid || !timerId) return;

    const load = async () => {
      try {
        const snap = await get(ref(database, `users/${uid}/timers/${timerId}/accumulatedMs`));
        setHasAccumulatedMs(snap.exists());
      } catch (e) {
        console.error(e);
        setError('타이머를 불러오는 중 오류가 발생했습니다.');
      }
    };

    load();
  }, [uid, timerId]);

  if (error) {
    return <div className="container py-5"><p>{error}</p></div>;
  }

  if (hasAccumulatedMs == null) {
    return <div className="container py-5"><p>로딩 중...</p></div>;
  }

  return hasAccumulatedMs ? <AccumulatedTimerPage /> : <RecordTimerPage />;
}
