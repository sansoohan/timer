// pages/TimersPage/components/TimerRow.tsx
import { generatePath, useNavigate, useParams } from 'react-router-dom';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { HamburgerDivider } from '~/components/HamburgerDivider';
import { HamburgerMenu } from '~/components/HamburgerMenu';
import { ROUTE_USER_TIMER } from '~/constants/routes';
import type { TimerItem } from '~/types/timer';

function formatAccumulatedTime(ms: number): string {
  const totalSeconds = Math.floor(ms / 1000);
  const totalHours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  return `${String(totalHours).padStart(5, '0')}:${String(minutes).padStart(
    2,
    '0',
  )}:${String(seconds).padStart(2, '0')}`;
}

function formatElapsedSince(ms: number): string {
  const totalSeconds = Math.floor(Math.max(0, ms) / 1000);
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  return `${days}일 ${hours}시간 ${minutes}분 ${seconds}초 전에 실행됨`;
}

type TimerRowProps = {
  timer: TimerItem;
  now: number;
  onToggle: (timer: TimerItem) => void;
  onRename: (timer: TimerItem) => void;
  onDelete: (timer: TimerItem) => void;
};

export function TimerRow({
  timer,
  now,
  onToggle,
  onRename,
  onDelete,
}: TimerRowProps) {
  const { uid } = useParams<{ uid: string }>();
  const nav = useNavigate();

  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: timer.id });

  const isAccumulated = typeof timer.accumulatedMs === 'number';
  const isRunning = isAccumulated && timer.currentStartAt != null;
  const displayName = timer.name.trim() || ' ';
  const elapsedMs = isRunning
    ? Math.max(0, now - (timer.currentStartAt ?? 0))
    : 0;
  const displayMs = (timer.accumulatedMs ?? 0) + elapsedMs;
  const timerColor = isRunning ? 'text-success' : 'text-light';

  const handleOpenDetail = () => {
    if (!uid) return;
    nav(generatePath(ROUTE_USER_TIMER, { uid, timerId: timer.id }));
  };

  return (
    <div
      ref={setNodeRef}
      className='col-12 col-lg-6'
      style={{
        transform: CSS.Transform.toString(transform),
        transition,
        zIndex: isDragging ? 10 : undefined,
        opacity: isDragging ? 0.75 : 1,
      }}
    >
      <div className='border rounded-3 px-3 py-3 shadow-sm h-100'>
        <div className='d-flex align-items-start justify-content-between gap-3'>
          <button
            type='button'
            className='flex-grow-1 text-start bg-transparent border-0 p-0'
            style={{ minWidth: 0 }}
            onClick={() => onToggle(timer)}
          >
            <div
              className={`fw-semibold text-truncate mb-2 ${timerColor}`}
              style={{ fontSize: '1rem', minHeight: '1.5rem' }}
            >
              {displayName}
            </div>

            <div
              className={`fw-bold ${timerColor}`}
              style={{
                fontSize: 'clamp(1.35rem, 3vw, 2.1rem)',
                letterSpacing: '0.04em',
                lineHeight: 1.1,
                fontVariantNumeric: 'tabular-nums',
              }}
            >
              {isAccumulated
                ? formatAccumulatedTime(displayMs)
                : timer.recentStartAt == null
                  ? '이전기록이 없습니다'
                  : formatElapsedSince(now - timer.recentStartAt)}
            </div>
          </button>

          <div
            className='d-flex align-items-center gap-1'
            onClick={e => e.stopPropagation()}
          >
            <button
              type='button'
              className='btn btn-sm btn-link text-secondary text-decoration-none px-1'
              title='드래그해서 순서 변경'
              aria-label='드래그해서 순서 변경'
              {...attributes}
              {...listeners}
              style={{
                cursor: isDragging ? 'grabbing' : 'grab',
                touchAction: 'none',
                fontSize: '1.25rem',
                lineHeight: 1,
              }}
            >
              ⠿
            </button>

            <HamburgerMenu>
              <li>
                <button
                  className='dropdown-item'
                  type='button'
                  onClick={handleOpenDetail}
                >
                  {isAccumulated ? '누적시간 상세보기' : '기록시간 상세보기'}
                </button>
              </li>

              <li>
                <button
                  className='dropdown-item'
                  type='button'
                  onClick={() => onRename(timer)}
                >
                  타이머명 변경
                </button>
              </li>

              <HamburgerDivider />

              <li>
                <button
                  className='dropdown-item text-danger'
                  type='button'
                  onClick={() => onDelete(timer)}
                >
                  타이머 삭제
                </button>
              </li>
            </HamburgerMenu>
          </div>
        </div>
      </div>
    </div>
  );
}
