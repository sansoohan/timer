// utils/rotation.ts
import { getISOWeek } from 'date-fns';
import type { TimerItem } from '~/types/timer';

export type RotationMessage = {
  text: string;
};

export type RotationTrigger = 'start' | 'stop';

export function getSessionCount(timer: TimerItem): number {
  return Object.keys(timer.sessions ?? {}).length;
}

function addMessage(result: RotationMessage[], text?: string) {
  const value = text?.trim();
  if (value) result.push({ text: value });
}

export function getRotationMessages(
  timer: TimerItem,
  at: number,
  sessionCount: number,
  trigger: RotationTrigger,
): RotationMessage[] {
  const date = new Date(at);

  let isOddDay = sessionCount % 2 === 1;
  let isOddWeek = getISOWeek(date) % 2 === 1;
  let isOddMonth = (date.getMonth() + 1) % 2 === 1;

  // 종료 클릭에서만 다음 로테이션 문구를 보여준다.
  // DB 값은 변경하지 않고 표시용 홀짝만 반전한다.
  if (trigger === 'stop') {
    isOddDay = !isOddDay;
    isOddWeek = !isOddWeek;
    isOddMonth = !isOddMonth;
  }

  const result: RotationMessage[] = [];

  addMessage(result, isOddDay ? timer.oddDayText : timer.evenDayText);
  addMessage(result, isOddWeek ? timer.oddWeekText : timer.evenWeekText);
  addMessage(result, isOddMonth ? timer.oddMonthText : timer.evenMonthText);

  return result;
}
