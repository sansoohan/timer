// types/timer.ts
export type TimerSession = {
  startAt: number;
  endAt?: number;
};

type BaseTimerItem = {
  id: string;
  name: string;

  // 화면 정렬 순서. 기존 데이터 호환을 위해 optional.
  order?: number;

  recentStartAt: number | null;
  sessions: Record<string, TimerSession>;

  oddDayText?: string;
  evenDayText?: string;
  oddWeekText?: string;
  evenWeekText?: string;
  oddMonthText?: string;
  evenMonthText?: string;
};

export type AccumulatedTimerItem = BaseTimerItem & {
  accumulatedMs: number;
  currentStartAt: number | null;
};

export type RecordTimerItem = BaseTimerItem & {
  accumulatedMs?: never;
  currentStartAt?: never;
};

export type TimerItem = AccumulatedTimerItem | RecordTimerItem;
